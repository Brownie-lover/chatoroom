const proto = location.protocol === 'https:' ? 'wss' : 'ws';
const ws = new WebSocket(`${proto}://${location.host}`);

const logEl = document.getElementById('log');
const usersEl = document.getElementById('users');
const countEl = document.getElementById('count');
const form = document.getElementById('form');
const msgInput = document.getElementById('msg');
const nameInput = document.getElementById('name');
const fileEl = document.getElementById('file');
const fileBtn = document.getElementById('fileBtn');
const knownEl = document.getElementById('known');
const countToggleEl = document.getElementById('countToggle');
const sidebarToggle = document.getElementById('sidebarToggle');
const sidebarBody = document.getElementById('sidebarBody');
const clearBtn = document.getElementById('clearBtn');
const authBtn = document.getElementById('authBtn');
const adminkeyEl = document.getElementById('adminkey');

let me = { id: null, name: null, owner: false };
const users = new Map();
let knownNames = [];
let selectedUser = null;

const SAVED_NAME_KEY = 'chat-name';
if (localStorage.getItem(SAVED_NAME_KEY)) {
  nameInput.value = localStorage.getItem(SAVED_NAME_KEY);
}

clearBtn.addEventListener('click', () => {
  if (confirm('Clear the chat history?')) {
    ws.send(JSON.stringify({ type: 'clear' }));
  }
});

authBtn.addEventListener('click', () => {
  const key = adminkeyEl.value.trim();
  if (!key) return alert('Enter an admin key');
  ws.send(JSON.stringify({ type: 'auth', key }));
});

fileBtn.addEventListener('click', () => fileEl.click());
fileEl.addEventListener('change', () => {
  const file = fileEl.files[0];
  if (!file) return;
  if (file.size > 5 * 1024 * 1024) {
    alert('File too large (max 5 MB)');
    fileEl.value = '';
    return;
  }
  const reader = new FileReader();
  reader.onload = () => {
    ws.send(JSON.stringify({
      type: 'file',
      name: file.name,
      size: file.size,
      mime: file.type,
      data: reader.result,
    }));
    fileEl.value = '';
  };
  reader.readAsDataURL(file);
});

sidebarToggle.addEventListener('click', () => {
  sidebarBody.classList.toggle('open');
});

function renderKnown() {
  knownEl.innerHTML = '';
  for (const n of knownNames) {
    const li = document.createElement('li');
    li.textContent = n;
    knownEl.appendChild(li);
  }
}

function scroll() { logEl.scrollTop = logEl.scrollHeight; }

function time(ts) {
  const d = new Date(ts);
  return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

function canDelete(userId) {
  return me.owner || userId === me.id;
}

function addLine(kind, html, msgId, userId) {
  const div = document.createElement('div');
  div.className = 'msg ' + kind;
  div.innerHTML = html;
  if (msgId) div.dataset.id = msgId;
  if (msgId && canDelete(userId)) {
    const del = document.createElement('button');
    del.className = 'del';
    del.textContent = '✕';
    del.title = 'Delete message';
    del.onclick = (e) => {
      e.stopPropagation();
      ws.send(JSON.stringify({ type: 'delete', id: msgId }));
    };
    div.appendChild(del);
  }
  logEl.appendChild(div);
  scroll();
  return div;
}

function addFileLine(kind, msgId, userId, innerHtml) {
  const div = document.createElement('div');
  div.className = 'msg file ' + kind;
  div.innerHTML = innerHtml;
  if (msgId) div.dataset.id = msgId;
  if (msgId && canDelete(userId)) {
    const del = document.createElement('button');
    del.className = 'del';
    del.textContent = '✕';
    del.title = 'Delete message';
    del.onclick = (e) => {
      e.stopPropagation();
      ws.send(JSON.stringify({ type: 'delete', id: msgId }));
    };
    div.appendChild(del);
  }
  logEl.appendChild(div);
  scroll();
  return div;
}

function renderUsers() {
  usersEl.innerHTML = '';
  for (const [id, name] of users) {
    const li = document.createElement('li');
    const dot = document.createElement('span');
    dot.className = 'status';
    dot.textContent = '●';
    li.appendChild(dot);
    const label = document.createElement('span');
    label.textContent = name + (id === me.id ? ' (you)' : '');
    li.appendChild(label);
    li.style.cursor = 'pointer';
    li.onclick = () => {
      selectedUser = selectedUser === id ? null : id;
      renderUsers();
      msgInput.placeholder = selectedUser
        ? `Private to ${users.get(selectedUser)}...`
        : 'Type a message...';
      msgInput.focus();
    };
    if (id === selectedUser) li.style.background = '#334155';
    if (me.owner && id !== me.id) {
      const kick = document.createElement('button');
      kick.className = 'kick';
      kick.textContent = 'Kick';
      kick.onclick = (e) => {
        e.stopPropagation();
        if (confirm(`Kick ${name}?`)) {
          ws.send(JSON.stringify({ type: 'kick', id }));
        }
      };
      li.appendChild(kick);
    }
    usersEl.appendChild(li);
  }
  countEl.textContent = users.size;
  if (countToggleEl) countToggleEl.textContent = users.size;
}

nameInput.addEventListener('change', () => {
  const name = nameInput.value.trim();
  if (name) {
    localStorage.setItem(SAVED_NAME_KEY, name);
    ws.send(JSON.stringify({ type: 'name', name }));
  }
});

form.addEventListener('submit', (e) => {
  e.preventDefault();
  const text = msgInput.value.trim();
  if (!text) return;
  if (selectedUser) {
    ws.send(JSON.stringify({ type: 'private', to: selectedUser, text }));
    addLine('private',
      `<span class="who">You → ${users.get(selectedUser)}:</span><span>${escapeHtml(text)}</span><span class="when">${time(Date.now())}</span>`);
  } else {
    ws.send(JSON.stringify({ type: 'message', text }));
  }
  msgInput.value = '';
});

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  }[c]));
}

function fileHtml(m) {
  const who = `<span class="who">${escapeHtml(m.user)}:</span>`;
  const when = `<span class="when">${time(m.timestamp)}</span>`;
  if (m.mime && m.mime.startsWith('image/')) {
    return `${who}<span><a href="${m.data}" target="_blank" download="${escapeHtml(m.name)}"><img class="chat-img" src="${m.data}" alt="${escapeHtml(m.name)}" /></a></span>${when}`;
  }
  if (m.mime && m.mime.startsWith('video/')) {
    return `${who}<span class="filemedia"><video class="chat-video" src="${m.data}" controls preload="metadata"></video></span>${when}`;
  }
  if (m.mime && m.mime.startsWith('audio/')) {
    return `${who}<span class="filemedia"><audio class="chat-audio" src="${m.data}" controls preload="metadata"></audio></span>${when}`;
  }
  const kb = (m.size / 1024).toFixed(1);
  return `${who}<span><a class="filelink" href="${m.data}" download="${escapeHtml(m.name)}">📄 ${escapeHtml(m.name)} (${kb} KB)</a></span>${when}`;
}

ws.onmessage = (e) => {
  const d = JSON.parse(e.data);
  switch (d.type) {
    case 'me':
      me = { id: d.id, name: d.name, owner: d.owner };
      if (!nameInput.value) nameInput.value = d.name;
      if (me.owner) {
        clearBtn.classList.remove('hidden');
        authBtn.classList.add('hidden');
        adminkeyEl.classList.add('hidden');
      }
      break;
    case 'known':
      knownNames = d.names;
      renderKnown();
      break;
    case 'history':
      logEl.innerHTML = '';
      for (const m of d.messages) {
        if (m.type === 'message') {
          addLine('recent',
            `<span class="who">${escapeHtml(m.user)}:</span><span>${escapeHtml(m.text)}</span><span class="when">${time(m.timestamp)}</span>`,
            m.id, m.userId);
        } else if (m.type === 'file') {
          addFileLine('recent', m.id, m.userId, fileHtml(m));
        }
      }
      break;
    case 'users':
      users.clear();
      for (const u of d.users) users.set(u.id, u.name);
      renderUsers();
      break;
    case 'message':
      addLine('',
        `<span class="who">${escapeHtml(d.user)}:</span><span>${escapeHtml(d.text)}</span><span class="when">${time(d.timestamp)}</span>`,
        d.id, d.userId);
      break;
    case 'file':
      addFileLine('', d.id, d.userId, fileHtml(d));
      break;
    case 'delete':
      const el = logEl.querySelector(`[data-id="${d.id}"]`);
      if (el) el.remove();
      break;
    case 'private':
      if (d.toId === me.id) {
        addLine('private',
          `<span class="who">${escapeHtml(d.from)} → you:</span><span>${escapeHtml(d.text)}</span><span class="when">${time(d.timestamp)}</span>`);
      }
      break;
    case 'system':
      addLine('system', escapeHtml(d.text));
      break;
    case 'error':
      addLine('system', '⚠ ' + escapeHtml(d.text));
      break;
    case 'kicked':
      addLine('system', '⛔ ' + escapeHtml(d.text));
      ws.close();
      break;
  }
};

ws.onopen = () => {
  const saved = localStorage.getItem(SAVED_NAME_KEY);
  if (saved) ws.send(JSON.stringify({ type: 'name', name: saved }));
};

ws.onclose = () => addLine('system', 'Disconnected from server');
ws.onerror = () => addLine('system', 'Connection error');