const proto = location.protocol === 'https:' ? 'wss' : 'ws';
const ws = new WebSocket(`${proto}://${location.host}`);

const logEl = document.getElementById('log');
const usersEl = document.getElementById('users');
const countEl = document.getElementById('count');
const form = document.getElementById('form');
const msgInput = document.getElementById('msg');
const nameInput = document.getElementById('name');
const knownEl = document.getElementById('known');
const clearBtn = document.getElementById('clearBtn');
const authBtn = document.getElementById('authBtn');
const adminkeyEl = document.getElementById('adminkey');

let me = { id: null, name: null, owner: false };
const users = new Map();
let knownNames = [];
let selectedUser = null;

clearBtn.addEventListener('click', () => {
  if (confirm('Clear the chat history?')) {
    ws.send(JSON.stringify({ type: 'clear' }));
  }
});

authBtn.addEventListener('click', () => {
  const key = adminkeyEl.value.trim();
  if (!key) return alert('Enter an admin key');
  ws.send(JSON.stringify({ type: 'auth', key }));
});

function renderKnown() {
  knownEl.innerHTML = '';
  for (const n of knownNames) {
    const li = document.createElement('li');
    li.textContent = n;
    knownEl.appendChild(li);
  }
}

function scroll() { logEl.scrollTop = logEl.scrollHeight; }

function time(ts) {
  const d = new Date(ts);
  return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

function addLine(kind, html, msgId) {
  const div = document.createElement('div');
  div.className = 'msg ' + kind;
  div.innerHTML = html;
  if (msgId) div.dataset.id = msgId;
  if (msgId && me.owner) {
    const del = document.createElement('button');
    del.className = 'del';
    del.textContent = '✕';
    del.title = 'Delete message';
    del.onclick = (e) => {
      e.stopPropagation();
      ws.send(JSON.stringify({ type: 'delete', id: msgId }));
    };
    div.appendChild(del);
  }
  logEl.appendChild(div);
  scroll();
  return div;
}

function renderUsers() {
  usersEl.innerHTML = '';
  for (const [id, name] of users) {
    const li = document.createElement('li');
    const dot = document.createElement('span');
    dot.className = 'status';
    dot.textContent = '●';
    li.appendChild(dot);
    const label = document.createElement('span');
    label.textContent = name + (id === me.id ? ' (you)' : '');
    li.appendChild(label);
    li.style.cursor = 'pointer';
    li.onclick = () => {
      selectedUser = selectedUser === id ? null : id;
      renderUsers();
      msgInput.placeholder = selectedUser
        ? `Private to ${users.get(selectedUser)}...`
        : 'Type a message...';
      msgInput.focus();
    };
    if (id === selectedUser) li.style.background = '#334155';
    if (me.owner && id !== me.id) {
      const kick = document.createElement('button');
      kick.className = 'kick';
      kick.textContent = 'Kick';
      kick.onclick = (e) => {
        e.stopPropagation();
        if (confirm(`Kick ${name}?`)) {
          ws.send(JSON.stringify({ type: 'kick', id }));
        }
      };
      li.appendChild(kick);
    }
    usersEl.appendChild(li);
  }
  countEl.textContent = users.size;
}

nameInput.addEventListener('change', () => {
  const name = nameInput.value.trim();
  if (name) ws.send(JSON.stringify({ type: 'name', name }));
});

form.addEventListener('submit', (e) => {
  e.preventDefault();
  const text = msgInput.value.trim();
  if (!text) return;
  if (selectedUser) {
    ws.send(JSON.stringify({ type: 'private', to: selectedUser, text }));
    addLine('private',
      `<span class="who">You → ${users.get(selectedUser)}:</span><span>${escapeHtml(text)}</span><span class="when">${time(Date.now())}</span>`);
  } else {
    ws.send(JSON.stringify({ type: 'message', text }));
  }
  msgInput.value = '';
});

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  }[c]));
}

ws.onmessage = (e) => {
  const d = JSON.parse(e.data);
  switch (d.type) {
    case 'me':
      me = { id: d.id, name: d.name, owner: d.owner };
      if (!nameInput.value) nameInput.value = d.name;
      if (me.owner) {
        clearBtn.classList.remove('hidden');
        authBtn.classList.add('hidden');
        adminkeyEl.classList.add('hidden');
      }
      break;
    case 'known':
      knownNames = d.names;
      renderKnown();
      break;
    case 'history':
      logEl.innerHTML = '';
      for (const m of d.messages) {
        if (m.type === 'message') {
          addLine('recent',
            `<span class="who">${escapeHtml(m.user)}:</span><span>${escapeHtml(m.text)}</span><span class="when">${time(m.timestamp)}</span>`,
            m.id);
        }
      }
      break;
    case 'users':
      users.clear();
      for (const u of d.users) users.set(u.id, u.name);
      renderUsers();
      break;
    case 'message':
      addLine('',
        `<span class="who">${escapeHtml(d.user)}:</span><span>${escapeHtml(d.text)}</span><span class="when">${time(d.timestamp)}</span>`,
        d.id);
      break;
    case 'delete':
      const el = logEl.querySelector(`[data-id="${d.id}"]`);
      if (el) el.remove();
      break;
    case 'private':
      if (d.toId === me.id) {
        addLine('private',
          `<span class="who">${escapeHtml(d.from)} → you:</span><span>${escapeHtml(d.text)}</span><span class="when">${time(d.timestamp)}</span>`);
      }
      break;
    case 'system':
      addLine('system', escapeHtml(d.text));
      break;
    case 'error':
      addLine('system', '⚠ ' + escapeHtml(d.text));
      break;
    case 'kicked':
      addLine('system', '⛔ ' + escapeHtml(d.text));
      ws.close();
      break;
  }
};

ws.onclose = () => addLine('system', 'Disconnected from server');
ws.onerror = () => addLine('system', 'Connection error');