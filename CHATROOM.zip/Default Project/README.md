# Public Chatroom

A public multi-room chat server accessible over the internet, with a web client and a terminal (Python) client.

## Components
- `server.js` — Node.js server (HTTP static files + WebSocket protocol).
- `public/` — browser client (HTML/CSS/JS).
- `client.py` — Python terminal client (uses `websockets`).
- `package.json` — Node dependencies (`ws`).

## Run the server
```bash
npm install
npm start
```
Serves on `0.0.0.0:8080` so anyone who can reach that port can connect.

## Connect
- Browser: open `http://<server-ip>:8080`
- Python: `python client.py ws://<server-ip>:8080`

## Make it public (outside your LAN)
The server binds to `0.0.0.0`, but to be reachable from the public internet you need one of:
1. **Port forwarding** on your router (forward TCP 8080 to your machine), or
2. A **tunnel** (easiest, no router changes): `ssh -R 80:localhost:8080 nokey@localhost.run`, or use Cloudflare Tunnel / ngrok:
   ```bash
   ngrok http 8080
   ```
   (ngrok gives you `ws://`/`wss://` addresses that your client works with as-is). Note the browser uses `wss` automatically on `https` pages.
3. A **VPS/cloud host** (deploy behind a reverse proxy).

## Protocol (WebSocket JSON)
| type      | fields |
|-----------|--------|
| `name`    | `{ name }` set/change display name |
| `message` | `{ text }` broadcast to room |
| `private` | `{ to, text }` direct message by user id |
| `users`   | server -> list of `{ id, name }` |
| `me`      | server -> your `{ id, name }` |
| `system`  | server -> join/leave/rename notices |
| `error`   | server -> error text |