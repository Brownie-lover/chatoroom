const http = require('http');
const fs = require('fs');
const path = require('path');

const crypto = require('crypto');
const { WebSocketServer } = require('ws');

const PORT = process.env.PORT || 8080;
const HOST = '0.0.0.0';
const MAX_HISTORY = 100;

const clients = new Map(); // ws -> { name, id }
const history = []; // { type, id, user, userId, text, timestamp }

const httpServer = http.createServer((req, res) => {
  let url = req.url.split('?')[0];
  if (url === '/') url = '/index.html';
  const filePath = path.join(__dirname, 'public', url === '/' ? 'index.html' : url);

  const safe = path.resolve(filePath).startsWith(path.resolve(__dirname, 'public'));
  if (!safe) {
    res.writeHead(403);
    return res.end('Forbidden');
  }

  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404);
      return res.end('Not found');
    }
    const ext = path.extname(filePath);
    const types = {
      '.html': 'text/html',
      '.js': 'text/javascript',
      '.css': 'text/css',
    };
    res.writeHead(200, { 'Content-Type': types[ext] || 'application/octet-stream' });
    res.end(data);
  });
});

const wss = new WebSocketServer({ server: httpServer });

function broadcast(obj) {
  const msg = JSON.stringify(obj);
  for (const ws of clients.keys()) {
    if (ws.readyState === 1) ws.send(msg);
  }
}

function userList() {
  return [...clients.values()].map((c) => ({
    id: c.id,
    name: c.name,
  }));
}

function send(ws, obj) {
  if (ws.readyState === 1) ws.send(JSON.stringify(obj));
}

function pushHistory(msg) {
  history.push(msg);
  if (history.length > MAX_HISTORY) history.shift();
}

function sendMessage(ws, { text, timestamp = Date.now() }) {
  const c = clients.get(ws);
  const msg = {
    type: 'message',
    id: crypto.randomUUID(),
    user: c.name,
    userId: c.id,
    text: String(text).slice(0, 2000),
    timestamp,
  };
  pushHistory(msg);
  broadcast(msg);
}

function sendPrivate(ws, { to, text, timestamp = Date.now() }) {
  const c = clients.get(ws);
  const target = [...clients.entries()].find(([, v]) => v.id === to);
  if (!target) {
    return send(ws, { type: 'error', text: 'User not found' });
  }
  const payload = {
    type: 'private',
    id: crypto.randomUUID(),
    from: c.name,
    fromId: c.id,
    to: target[1].name,
    toId: target[1].id,
    text: String(text).slice(0, 2000),
    timestamp,
  };
  send(target[0], payload);
  send(ws, payload);
}

wss.on('connection', (ws) => {
  const id = crypto.randomUUID().slice(0, 8);
  clients.set(ws, { id, name: 'anon-' + id });
  send(ws, { type: 'me', id, name: 'anon-' + id });
  send(ws, { type: 'history', messages: history });
  broadcast({ type: 'users', users: userList() });

  ws.on('message', (raw) => {
    let data;
    try {
      data = JSON.parse(raw);
    } catch {
      return send(ws, { type: 'error', text: 'Invalid JSON' });
    }

    const c = clients.get(ws);
    switch (data.type) {
      case 'name':
        const name = String(data.name || '').trim().slice(0, 24);
        if (!name) return send(ws, { type: 'error', text: 'Name cannot be empty' });
        const oldName = c.name;
        c.name = name;
        broadcast({
          type: 'system',
          text: `${oldName} renamed to ${name}`,
        });
        send(ws, { type: 'me', id: c.id, name });
        broadcast({ type: 'users', users: userList() });
        break;
      case 'message':
        sendMessage(ws, data);
        break;
      case 'private':
        sendPrivate(ws, data);
        break;
      default:
        send(ws, { type: 'error', text: 'Unknown message type' });
    }
  });

  ws.on('close', () => {
    const c = clients.get(ws);
    if (c) {
      broadcast({ type: 'system', text: `${c.name} left` });
    }
    clients.delete(ws);
    broadcast({ type: 'users', users: userList() });
  });
});

httpServer.listen(PORT, HOST, () => {
  console.log(`Chatroom server running on http://0.0.0.0:${PORT}`);
});