const proto = location.protocol === 'https:' ? 'wss' : 'ws';
const ws = new WebSocket(`${proto}://${location.host}`);

const logEl = document.getElementById('log');
const usersEl = document.getElementById('users');
const countEl = document.getElementById('count');
const form = document.getElementById('form');
const msgInput = document.getElementById('msg');
const nameInput = document.getElementById('name');

let me = { id: null, name: null };
const users = new Map();
let selectedUser = null;

function scroll() { logEl.scrollTop = logEl.scrollHeight; }

function time(ts) {
  const d = new Date(ts);
  return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

function addLine(kind, html) {
  const div = document.createElement('div');
  div.className = 'msg ' + kind;
  div.innerHTML = html;
  logEl.appendChild(div);
  scroll();
}

function renderUsers() {
  usersEl.innerHTML = '';
  for (const [id, name] of users) {
    const li = document.createElement('li');
    const dot = document.createElement('span');
    dot.className = 'status';
    dot.textContent = '●';
    li.appendChild(dot);
    const label = document.createElement('span');
    label.textContent = name + (id === me.id ? ' (you)' : '');
    li.appendChild(label);
    li.style.cursor = 'pointer';
    li.onclick = () => {
      selectedUser = selectedUser === id ? null : id;
      renderUsers();
      msgInput.placeholder = selectedUser
        ? `Private to ${users.get(selectedUser)}...`
        : 'Type a message...';
      msgInput.focus();
    };
    if (id === selectedUser) li.style.background = '#334155';
    usersEl.appendChild(li);
  }
  countEl.textContent = users.size;
}

nameInput.addEventListener('change', () => {
  const name = nameInput.value.trim();
  if (name) ws.send(JSON.stringify({ type: 'name', name }));
});

form.addEventListener('submit', (e) => {
  e.preventDefault();
  const text = msgInput.value.trim();
  if (!text) return;
  if (selectedUser) {
    ws.send(JSON.stringify({ type: 'private', to: selectedUser, text }));
    addLine('private',
      `<span class="who">You → ${users.get(selectedUser)}:</span><span>${escapeHtml(text)}</span><span class="when">${time(Date.now())}</span>`);
  } else {
    ws.send(JSON.stringify({ type: 'message', text }));
  }
  msgInput.value = '';
});

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  }[c]));
}

ws.onmessage = (e) => {
  const d = JSON.parse(e.data);
  switch (d.type) {
    case 'me':
      me = { id: d.id, name: d.name };
      if (!nameInput.value) nameInput.value = d.name;
      break;
    case 'history':
      for (const m of d.messages) {
        if (m.type === 'message') {
          addLine('recent',
            `<span class="who">${escapeHtml(m.user)}:</span><span>${escapeHtml(m.text)}</span><span class="when">${time(m.timestamp)}</span>`);
        }
      }
      break;
    case 'users':
      users.clear();
      for (const u of d.users) users.set(u.id, u.name);
      renderUsers();
      break;
    case 'message':
      addLine('',
        `<span class="who">${escapeHtml(d.user)}:</span><span>${escapeHtml(d.text)}</span><span class="when">${time(d.timestamp)}</span>`);
      break;
    case 'private':
      if (d.toId === me.id) {
        addLine('private',
          `<span class="who">${escapeHtml(d.from)} → you:</span><span>${escapeHtml(d.text)}</span><span class="when">${time(d.timestamp)}</span>`);
      }
      break;
    case 'system':
      addLine('system', escapeHtml(d.text));
      break;
    case 'error':
      addLine('system', '⚠ ' + escapeHtml(d.text));
      break;
  }
};

ws.onclose = () => addLine('system', 'Disconnected from server');
ws.onerror = () => addLine('system', 'Connection error');