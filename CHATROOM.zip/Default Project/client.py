import asyncio
import json
import sys

try:
    import websockets
except ImportError:
    print("Missing 'websockets'. Install it with: pip install websockets")
    sys.exit(1)

DEFAULT_URL = "ws://localhost:8080"


async def receive(ws):
    async for raw in ws:
        data = json.loads(raw)
        t = data.get("type")
        if t == "history":
            print("\r--- chat history ---")
            for m in data["messages"]:
                if m.get("type") == "message":
                    print(f"\r  {m['user']}: {m['text']}")
            print("--- end of history ---")
        elif t == "message":
            print(f"\r{data['user']}: {data['text']}")
        elif t == "private":
            print(f"\r[private] {data['from']} -> {data['to']}: {data['text']}")
        elif t == "system":
            print(f"\r* {data['text']}")
        elif t == "users":
            names = ", ".join(u["name"] for u in data["users"])
            print(f"\r[online {len(data['users'])}] {names}")
        elif t == "me":
            print(f"\r* You are connected as: {data['name']}")
        elif t == "error":
            print(f"\r! {data['text']}")


async def main():
    url = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_URL
    name = input("Your name: ").strip() or "py-user"

    while True:
        try:
            async with websockets.connect(url) as ws:
                await ws.send(json.dumps({"type": "name", "name": name}))
                loop = asyncio.get_running_loop()
                task = loop.create_task(receive(ws))
                print("Connected. Type a message and press Enter. "
                      "Commands: /name X  /pm <id> TEXT  /users  /quit")
                try:
                    while True:
                        line = await loop.run_in_executor(None, input)
                        if line == "/quit":
                            task.cancel()
                            return
                        if line.startswith("/name "):
                            new = line[6:].strip()
                            await ws.send(json.dumps({"type": "name", "name": new}))
                        elif line.startswith("/pm "):
                            parts = line[4:].split(" ", 1)
                            if len(parts) == 2:
                                await ws.send(json.dumps({
                                    "type": "private", "to": parts[0], "text": parts[1]}))
                        elif line == "/users":
                            await ws.send(json.dumps({"type": "ping"}))
                        elif line.strip():
                            await ws.send(json.dumps({"type": "message", "text": line}))
                finally:
                    task.cancel()
        except Exception as e:
            print(f"Connection lost ({e}). Retrying in 3s...")
            await asyncio.sleep(3)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nBye.")