import os
import subprocess
import sys
import time

NODE_BIN = "node"
NGROK_BIN = "ngrok"
SERVER_FILE = "server.js"
NGROK_DOMAIN = "jaunt-happiness-tinsmith.ngrok-free.dev"
PORT = "8080"


def ask_directory():
    default = os.path.dirname(os.path.abspath(__file__))
    path = input(f"Node.js server directory [default: {default}]: ").strip()
    return os.path.abspath(path or default)


def main():
    server_dir = ask_directory()
    server_path = os.path.join(server_dir, SERVER_FILE)

    if not os.path.isfile(server_path):
        print(f"[!] Could not find {SERVER_FILE} in {server_dir}")
        sys.exit(1)

    procs = []

    try:
        cmd_node = [NODE_BIN, server_path]
        print(f"[*] Starting: {' '.join(cmd_node)}")
        procs.append(subprocess.Popen(cmd_node, cwd=server_dir))

        cmd_ngrok = [NGROK_BIN, "http", PORT, f"--domain={NGROK_DOMAIN}"]
        print(f"[*] Starting: {' '.join(cmd_ngrok)}")
        procs.append(subprocess.Popen(cmd_ngrok, cwd=server_dir))

        print("[*] Both processes launched. Press Ctrl+C to stop.")
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n[*] Shutting down...")
    except FileNotFoundError as e:
        print(f"[!] Command not found: {e}")
        sys.exit(1)
    finally:
        for p in procs:
            p.terminate()
        for p in procs:
            try:
                p.wait(timeout=5)
            except subprocess.TimeoutExpired:
                p.kill()
        print("[*] Stopped.")


if __name__ == "__main__":
    main()